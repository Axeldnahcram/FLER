Première version du readme
